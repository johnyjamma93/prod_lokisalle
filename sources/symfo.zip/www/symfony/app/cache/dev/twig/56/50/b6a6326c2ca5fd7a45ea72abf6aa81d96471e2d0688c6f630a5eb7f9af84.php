<?php

/* BoAdminBundle:Default:home.html.twig */
class __TwigTemplate_5650b6a6326c2ca5fd7a45ea72abf6aa81d96471e2d0688c6f630a5eb7f9af84 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'home' => array($this, 'block_home'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_home($context, array $blocks = array())
    {
        // line 3
        echo "Bienvenue sur la page principale de l'exercice
<div align=\"center\"><img src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("img/smiley.png"), "html", null, true);
        echo "\" alt=\"image_symfony2\"></div>
";
    }

    public function getTemplateName()
    {
        return "BoAdminBundle:Default:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 4,  31 => 3,  28 => 2,);
    }
}
