<?php

/* base.html.twig */
class __TwigTemplate_1f8f705ce10890bcef7772701f0d6217fc7552c80860c477e57270ce81ff10c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
            'home' => array($this, 'block_home'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <title>SF2</title>
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <!-- Bootstrap -->
        <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" media=\"screen\">
        <style type=\"text/css\">
            body{
                padding-top: 60px;
            }
        </style>
    </head>
    <body>
<div class=\"navbar navbar-inverse navbar-fixed-top\">        
";
        // line 16
        $this->env->loadTemplate("BoAdminBundle:Default:menu.html.twig")->display($context);
        // line 17
        echo "</div>
        <div class=\"container\">
            <div class=\"row\">
                <!-- block body -->
                ";
        // line 21
        $this->displayBlock('body', $context, $blocks);
        // line 22
        echo " 
                ";
        // line 23
        $this->displayBlock('content', $context, $blocks);
        // line 25
        echo "                ";
        $this->displayBlock('home', $context, $blocks);
        // line 27
        echo "            </div>
        </div>

        <script src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("http://code.jquery.com/jquery.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    </body>
</html>";
    }

    // line 21
    public function block_body($context, array $blocks = array())
    {
        echo " 
                ";
    }

    // line 23
    public function block_content($context, array $blocks = array())
    {
        echo " 
                ";
    }

    // line 25
    public function block_home($context, array $blocks = array())
    {
        echo " 
                ";
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 25,  83 => 23,  76 => 21,  69 => 31,  65 => 30,  60 => 27,  57 => 25,  55 => 23,  52 => 22,  50 => 21,  44 => 17,  42 => 16,  30 => 7,  22 => 1,);
    }
}
