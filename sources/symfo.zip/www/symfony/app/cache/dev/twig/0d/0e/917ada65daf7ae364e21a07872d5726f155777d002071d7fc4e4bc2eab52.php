<?php

/* BoAdminBundle:Default:menu.html.twig */
class __TwigTemplate_0d0e917ada65daf7ae364e21a07872d5726f155777d002071d7fc4e4bc2eab52 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- menu -->
<div class=\"navbar navbar-inverse navbar-fixed-top\">
    <div class=\"navbar-inner\">
        <div class=\"container\">
            <a class=\"brand\" href=\"#\">Exercices</a>
            <div class=\"nav-collapse collapse\">
                <ul class=\"nav\">
                    <li class=\"active\"><a href=\"";
        // line 8
        echo $this->env->getExtension('routing')->getPath("admin.home");
        echo "\">Accueil</a></li>
                    <li class=\"active\"><a href=\"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("admin.aide");
        echo "\">Aide</a></li>
                    <li class=\"dropdown\">
                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">########## <b class=\"caret\"></b></a>
                        <ul class=\"dropdown-menu\">
                            <li class=\"nav-header\">##########</li>
                            <li><a href=\"#\">##########</a></li>
                            <li><a href=\"#\">##########</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- menu end -->";
    }

    public function getTemplateName()
    {
        return "BoAdminBundle:Default:menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 9,  28 => 8,  19 => 1,);
    }
}
