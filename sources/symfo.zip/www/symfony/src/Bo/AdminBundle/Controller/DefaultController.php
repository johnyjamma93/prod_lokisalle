<?php

namespace Bo\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

class DefaultController extends Controller 
{

    /**
     * @Route("/hello/{name}")
     * @Template()
     */
    public function indexAction($name) {
        return array('name' => $name);
    }

    /**
     * @Route("/aide", name="admin.aide")
     * @Template()
     */
    public function aideAction() {
        return array();
    }
    
    /**
     * @Route("/home", name="admin.home")
     * @Template()
     */
    public function homeAction() {
        return array();
    }

    public function calculAction(){$nbr_articles = rand(11,99999);
    return $this->render('BoAdminBundle:Default:calcul.html.twig', array('nbr_articles'=>$nbr_articles));
    }
}
