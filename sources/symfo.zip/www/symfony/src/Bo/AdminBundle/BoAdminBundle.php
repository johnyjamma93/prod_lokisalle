<?php

namespace Bo\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BoAdminBundle extends Bundle
{
}
